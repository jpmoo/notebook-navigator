# obsidian-compat

Compatibility helpers for Obsidian plugins that want to adopt newer plugin APIs while still supporting older app versions.

## Install

```sh
npm install obsidian-compat
```

`obsidian` is a peer dependency.

## `PluginSettingTabCompat<TSettings>`

A `PluginSettingTab` subclass that renders from `getSettingDefinitions()` on every Obsidian version. Use it in place of `PluginSettingTab` while supporting older app versions.

```ts
import type { SettingDefinitionItem } from 'obsidian';
import { PluginSettingTabCompat } from 'obsidian-compat';

class MyPluginSettingTab extends PluginSettingTabCompat<MySettings> {
    getSettingDefinitions(): SettingDefinitionItem<keyof MySettings & string>[] {
        return [
            { name: 'Foo', desc: 'Enables foo', control: { type: 'toggle', key: 'foo' } },
        ];
    }
}

// In the plugin's onload:
this.addSettingTab(new MyPluginSettingTab(this.app, this, this.settings));
```

Once `minAppVersion >= 1.13.0`, change `extends PluginSettingTabCompat` to `extends PluginSettingTab` and remove the `obsidian-compat` dependency. The plugin keeps working unchanged.

## `renderDefinitionsCompat(containerEl, items, options)`

Lower-level primitive: imperatively renders a `SettingDefinitionItem[]` into a container. Use this when you need a custom `resolve` (e.g. settings split across multiple objects, or computed values).

```ts
import { PluginSettingTab, type SettingDefinitionItem } from 'obsidian';
import { renderDefinitionsCompat } from 'obsidian-compat';

class MyPluginSettingTab extends PluginSettingTab {
    getSettingDefinitions(): SettingDefinitionItem[] {
        return [
            { name: 'Foo', desc: 'Enables foo', control: { type: 'toggle', key: 'foo' } },
        ];
    }

    display() {
        this.containerEl.empty();
        renderDefinitionsCompat(this.containerEl, this.getSettingDefinitions(), {
            resolve: (key) => ({
                value: (this.plugin as any).settings[key],
                onChange: (value) => {
                    (this.plugin as any).settings[key] = value;
                    this.plugin.saveData((this.plugin as any).settings);
                },
            }),
        });
    }
}
```

## Build

```sh
npm run build
```

Produces `dist/index.js` (CommonJS) and `dist/index.d.ts`. The bundle externalizes `obsidian` so the host-injected symbols are used at runtime.

## TODO: Publishing

Source lives in this monorepo. Publishing to npm is not yet wired up. Mirroring the approach used for the `obsidian` types package (https://github.com/obsidianmd/obsidian-api), the build output should be synced to a dedicated public repo (e.g. `obsidianmd/obsidian-compat`) and published from there on each release.
